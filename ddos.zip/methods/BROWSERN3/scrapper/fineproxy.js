const axios = require('axios');
const cheerio = require('cheerio');
const utils = require('../lib/utils');

/**
 * @param {Function} reportProgress
 * @returns {Promise<{total: number, valid: number, indo: number}>}
 */
async function ProxyElite(reportProgress = () => {}) {
  let total = 0;
  let valid = 0;
  let indo = 0;
  try {
    const mainPageUrl = 'https://fineproxy.org/free-proxy/';
    const mainPageResponse = await axios.get(mainPageUrl, {
      timeout: 30000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'
      }
    });
    const $ = cheerio.load(mainPageResponse.data);
    let totalProxiesCount = 0;
    $('p').each((i, el) => {
      const text = $(el).text();
      if (text.includes('Proxies online:')) {
        const strongText = $(el).find('strong').text();
        if (strongText && !isNaN(parseInt(strongText))) {
          totalProxiesCount = parseInt(strongText);
        }
      }
    });
    const nonceRegex = /nonce":"([^"]+)"/;
    const nonceMatch = mainPageResponse.data.match(nonceRegex);
    
    if (!nonceMatch || !nonceMatch[1]) {
      return { total, valid, indo };
    }
    const nonce = nonceMatch[1];
    const ajaxUrl = 'https://fineproxy.org/wp-admin/admin-ajax.php';
    const allProxies = [];
    let totalPages = Math.ceil(totalProxiesCount / 20) || 10;
    totalPages = Math.min(totalPages, 60);
    const pageNumbers = Array.from({ length: totalPages }, (_, i) => i + 1);
    const batchSize = 5;  
    for (let i = 0; i < pageNumbers.length; i += batchSize) {
      const batch = pageNumbers.slice(i, i + batchSize);
      const batchPromises = batch.map(page => fetchPage(page, ajaxUrl, nonce, mainPageUrl));
      const batchResults = await Promise.all(batchPromises);
      
      batchResults.forEach(proxies => {
        if (proxies && proxies.length) {
          allProxies.push(...proxies);
        }
      });
      
      if (i + batchSize < pageNumbers.length) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
    const uniqueProxies = [...new Set(allProxies)];
    total = uniqueProxies.length;
    for (let i = 0; i < uniqueProxies.length; i++) {
      const proxy = uniqueProxies[i];
      reportProgress(i + 1);
      try {
        await utils.writeProxy(proxy, false);
        valid++;
        const isIndo = await utils.isIndonesianProxy(proxy);
        if (isIndo) {
          indo++;
          await utils.writeProxy(proxy, true);
        }
      } catch (error) {
      }
    }
  } catch (error) {
  }
  
  return { total, valid, indo };
}

async function fetchPage(page, ajaxUrl, nonce, mainPageUrl) {
  try {
    const postData = new URLSearchParams();
    postData.append('action', 'proxylister_load_more');
    postData.append('nonce', nonce);
    postData.append('page', page);
    postData.append('atts[downloads]', 'true');
    
    const response = await axios.post(ajaxUrl, postData, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Origin': 'https://fineproxy.org',
        'Referer': mainPageUrl
      },
      timeout: 30000
    });
    
    if (response.data && response.data.success && response.data.data && response.data.data.rows) {
      const htmlContent = response.data.data.rows;
      return extractProxies(htmlContent);
    }
    
    return [];
  } catch (error) {
    return [];
  }
}

function extractProxies(htmlContent) {
  const proxies = [];
  const ipPortRegex = /<td class="table-ip">([^<]+)<\/td>\s*<td>([^<]+)<\/td>/g;
  let match;
  
  while ((match = ipPortRegex.exec(htmlContent)) !== null) {
    const ip = match[1].trim();
    const port = match[2].trim();
    if (ip && port) {
      const proxy = `${ip}:${port}`;
      proxies.push(proxy);
    }
  }
  
  return proxies;
}

module.exports = ProxyElite;